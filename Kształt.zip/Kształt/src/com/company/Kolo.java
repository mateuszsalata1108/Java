package com.company;

public class Kolo implements Kształt {
    double promien;
    Kolo(double promien){
        this.promien = promien;
    }
    @Override
    public double obliczPowierzchnie() {
        return Math.PI * promien * promien;
    }

    @Override
    public double obliczObwod() {
        return 2 * Math.PI * promien;
    }
}
