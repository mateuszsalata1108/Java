package com.company;

public interface Kształt {
    double obliczPowierzchnie();
    double obliczObwod();
}
