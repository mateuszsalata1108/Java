package com.company;

class Kwadrat implements Kształt{
    double dlugoscBoku;

    public Kwadrat(double dlugoscBoku){
        this.dlugoscBoku = dlugoscBoku;
    }

    public double obliczPowierzchnie(){
        return dlugoscBoku * dlugoscBoku;
    }

    public double obliczObwod(){
        return dlugoscBoku * 4;
    }
}

