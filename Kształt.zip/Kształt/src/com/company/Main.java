package com.company;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ArrayList<Kształt> ksztalty = new ArrayList<>();

        ksztalty.add(new Kolo(5));
        ksztalty.add(new Kwadrat(5));

        for(Kształt s : ksztalty){
            System.out.println("Powierzchnia kształtu to: " + s.obliczPowierzchnie());
        }

    }

}
