package com.company;

public class Main {

    public static void main(String[] args) {
        PrzykladPrzeciazanie przyklad = new PrzykladPrzeciazanie();
        przyklad.wypisz(4);
        przyklad.wypisz(3.14);
        przyklad.wypisz("To jest jakiś tekst");
    }
}
