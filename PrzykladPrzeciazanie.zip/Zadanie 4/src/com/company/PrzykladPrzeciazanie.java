package com.company;

public class PrzykladPrzeciazanie {
    public void wypisz(int x) {
        System.out.println("int= " + x);
    }

    public void wypisz(double x) {
        System.out.println("double= " + x);
    }

    public void wypisz(String x) {
        System.out.println("string= " + x);
    }
}
