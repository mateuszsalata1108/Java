package com.company;

public class Main {

    static void rysujUtil(int x1, int y1, int x2, int y2, Grafika g) {
        g.setPoczatek(x1, y1);
        g.setKoniec(x2, y2);
        g.Rysuj();
    }

    public static void main(String[] args) {
        rysujUtil(30, 30, 40, 40, new Linia());
        rysujUtil(50, 50, 60, 60, new Prostokat());
    }

}
