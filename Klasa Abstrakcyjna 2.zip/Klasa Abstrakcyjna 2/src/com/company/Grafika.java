package com.company;

abstract class Grafika {
    protected int x1, y1, x2, y2;
    public void setPoczatek(int x, int y){
        x = x1;
        y = y1;
    }
    public void setKoniec(int x, int y){
        x = x2;
        y = y2;
    }
    public abstract void Rysuj();
}