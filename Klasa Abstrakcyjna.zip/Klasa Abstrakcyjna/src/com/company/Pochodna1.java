package com.company;

class Pochodna1 extends Pochodna {
    public void g() {
        System.out.println("g() w Pochodna1");
    }
}
