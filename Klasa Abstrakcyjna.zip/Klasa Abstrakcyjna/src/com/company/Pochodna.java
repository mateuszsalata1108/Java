package com.company;

abstract class Pochodna extends Podstawowa {
    public void f() {
        System.out.println("f() w Pochodna");
    }
}
