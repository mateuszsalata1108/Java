package com.company;

abstract class Podstawowa {
    public abstract void f();
    public abstract void g();
    public void h() {
        System.out.println("h() w Podstawowa");
    }
}
