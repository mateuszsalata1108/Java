package com.company;

public class MojKalkulator implements Kalkulator {
    @Override
    public double dodaj(double a, double b) {
        return a+b;
    }

    @Override
    public double odejmij(double a, double b) {
        return a-b;
    }
    public double sinus(double deg){
        double radians = deg * PI / 180;
        return Math.sin(radians);
    }
}
