package com.company;

public interface Kalkulator {
    double PI = 3.14159;
    double dodaj(double a, double b);
    double odejmij(double a, double b);
}
