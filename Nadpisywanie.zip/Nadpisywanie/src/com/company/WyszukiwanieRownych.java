package com.company;

public class WyszukiwanieRownych extends Wyszukiwanie {
    @Override
    boolean porownaj(int a, int b) {
        if (a == b)
            return true;
        else
            return false;
    }
}
