package com.company;

abstract class Wyszukiwanie {
    abstract boolean porownaj(int a, int b);

    public int szukaj(int[] a, int ele) {
        for (int i = 0; i < a.length; i++) {
            if (porownaj(a[i], ele)) {
                return i;
            }
        }
        return -1;
    }
}
