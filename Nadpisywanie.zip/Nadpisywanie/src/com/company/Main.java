package com.company;

public class Main {

    public static void main(String[] args) {
        int[] tab = {10, 20, 30, 10, 20};
        int szukany = 30;
        WyszukiwanieRownych wyszukiwanieRownych = new WyszukiwanieRownych();
        int index = wyszukiwanieRownych.szukaj(tab, szukany);
        if (index == -1)
            System.out.println("Nie znaleziono");
        else
            System.out.println("Znaleziono w indeksie numer: " + index);
    }
}
