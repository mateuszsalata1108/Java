package com.company;

public interface PrzykladowyInterfejs {
    void przykladowaMetoda();
}
