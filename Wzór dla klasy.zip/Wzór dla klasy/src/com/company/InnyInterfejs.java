package com.company;

public interface InnyInterfejs {
    void innaMetoda();
}
